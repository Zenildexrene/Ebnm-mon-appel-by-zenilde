package com.monapell.myapp

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    data class Chapter(val title: String, val body: String)
    data class Palette(val bg: Int, val fg: Int, val bar: Int, val accent: Int)

    private val palettes = listOf(
        // Nuit (bleu profond + or KCC)
        Palette(Color.parseColor("#0B1B33"), Color.parseColor("#EDE6D3"), Color.parseColor("#06121F"), Color.parseColor("#E8B923")),
        // Jour
        Palette(Color.parseColor("#FFFFFF"), Color.parseColor("#1C1C1C"), Color.parseColor("#F2F2F2"), Color.parseColor("#B8860B")),
        // Sépia
        Palette(Color.parseColor("#F4ECD8"), Color.parseColor("#3B2F1E"), Color.parseColor("#E8DDC0"), Color.parseColor("#8A5A00"))
    )

    private lateinit var chapters: List<Chapter>
    private val prefs by lazy { getSharedPreferences("mon_appel", MODE_PRIVATE) }
    private var themeIdx = 0
    private var fontSize = 19f
    private var chapterIndex = 0
    private var scroll: ScrollView? = null

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        themeIdx = prefs.getInt("theme", 0)
        fontSize = prefs.getFloat("size", 19f)
        chapters = loadChapters()
        showHome()
    }

    override fun onPause() {
        super.onPause()
        saveProgress()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (scroll != null) {
            saveProgress()
            showHome()
        } else {
            super.onBackPressed()
        }
    }

    // ---------- Données ----------

    private fun loadChapters(): List<Chapter> {
        val text = try {
            assets.open("mon_appel.txt").bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            ""
        }
        val list = mutableListOf<Chapter>()
        var title = "Introduction"
        val sb = StringBuilder()
        fun flush() {
            val body = sb.toString().trim()
            if (body.isNotEmpty()) list.add(Chapter(title, formatBody(body)))
            sb.clear()
        }
        for (line in text.lines()) {
            if (line.startsWith("# ")) {
                flush()
                title = line.substring(2).trim()
            } else {
                sb.append(line).append('\n')
            }
        }
        flush()
        if (list.isEmpty()) {
            list.add(Chapter("Contenu manquant", "Ajoute le texte dans app/src/main/assets/mon_appel.txt"))
        }
        return list
    }

    // Les sauts de ligne simples (venant d'un PDF) deviennent des espaces,
    // les lignes vides séparent les paragraphes.
    private fun formatBody(raw: String): String =
        raw.split(Regex("\\n\\s*\\n"))
            .map { it.replace(Regex("\\s*\\n\\s*"), " ").trim() }
            .filter { it.isNotEmpty() }
            .joinToString("\n\n")

    private fun saveProgress() {
        val s = scroll ?: return
        prefs.edit().putInt("ch", chapterIndex).putInt("y", s.scrollY).apply()
    }

    // ---------- Utilitaires UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun styleBars(p: Palette) {
        window.statusBarColor = p.bar
        window.navigationBarColor = p.bar
    }

    private fun pill(label: String, filled: Boolean, p: Palette, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(20), dp(14), dp(20), dp(14))
            setTextColor(if (filled) p.bg else p.accent)
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                if (filled) setColor(p.accent) else {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), p.accent)
                }
            }
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                setMargins(dp(32), dp(8), dp(32), dp(8))
            }
            setOnClickListener { onClick() }
        }

    private fun barButton(label: String, p: Palette, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(p.accent)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener { onClick() }
        }

    // ---------- Écran d'accueil ----------

    private fun showHome() {
        scroll = null
        val p = palettes[0]
        styleBars(p)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(48), 0, dp(32))
        }

        // Médaillon "KCC"
        col.addView(TextView(this).apply {
            text = "KCC"
            gravity = Gravity.CENTER
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(p.accent)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(4), p.accent)
            }
            layoutParams = LinearLayout.LayoutParams(dp(130), dp(130)).apply {
                bottomMargin = dp(32)
            }
        })

        col.addView(TextView(this).apply {
            text = "MON APPEL"
            textSize = 40f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            letterSpacing = 0.08f
            setTextColor(p.accent)
            gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = "DIZOLELE-MPUNGU WAFIDUSWA Isaac\nPROPHÈTE DE L’ÉTERNEL"
            textSize = 14f
            letterSpacing = 0.05f
            setTextColor(p.fg)
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(14), dp(24), dp(4))
        })
        col.addView(TextView(this).apply {
            text = "Juillet 2010"
            textSize = 13f
            setTextColor(Color.parseColor("#9AA7BD"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(40))
        })

        val hasProgress = prefs.contains("ch")
        col.addView(pill(if (hasProgress) "Reprendre la lecture" else "Commencer la lecture", true, p) {
            if (hasProgress) {
                showReader(prefs.getInt("ch", 0).coerceIn(0, chapters.size - 1), prefs.getInt("y", 0))
            } else {
                showReader(0, 0)
            }
        })
        col.addView(pill("Chapitres", false, p) { showChapterList() })
        col.addView(pill("À propos", false, p) { showAbout() })

        col.addView(TextView(this).apply {
            text = "Application développée par Zenilde Lutu"
            textSize = 12f
            setTextColor(Color.parseColor("#9AA7BD"))
            gravity = Gravity.CENTER
            setPadding(0, dp(32), 0, 0)
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(p.bg)
            isFillViewport = true
            addView(col)
        })
    }

    // ---------- Lecteur ----------

    private fun showReader(index: Int, y: Int = 0) {
        chapterIndex = index
        val p = palettes[themeIdx]
        styleBars(p)
        val ch = chapters[index]

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }

        val body = TextView(this).apply {
            text = ch.body
            textSize = fontSize
            setTextColor(p.fg)
            typeface = Typeface.SERIF
            setLineSpacing(0f, 1.4f)
            setPadding(dp(22), dp(18), dp(22), dp(40))
        }

        // Barre du haut
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(p.bar)
            setPadding(dp(14), dp(4), dp(4), dp(4))
        }
        top.addView(TextView(this).apply {
            text = ch.title
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(p.accent)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        })
        top.addView(barButton("A−", p) {
            fontSize = (fontSize - 1f).coerceAtLeast(13f)
            body.textSize = fontSize
            prefs.edit().putFloat("size", fontSize).apply()
        })
        top.addView(barButton("A+", p) {
            fontSize = (fontSize + 1f).coerceAtMost(32f)
            body.textSize = fontSize
            prefs.edit().putFloat("size", fontSize).apply()
        })
        top.addView(barButton("◐", p) {
            themeIdx = (themeIdx + 1) % palettes.size
            prefs.edit().putInt("theme", themeIdx).apply()
            showReader(chapterIndex, scroll?.scrollY ?: 0)
        })
        root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        // Texte
        val sv = ScrollView(this).apply { addView(body) }
        scroll = sv
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Barre du bas
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(p.bar)
            gravity = Gravity.CENTER_VERTICAL
        }
        val prev = barButton("‹ Précédent", p) {
            if (chapterIndex > 0) showReader(chapterIndex - 1, 0)
        }
        val next = barButton("Suivant ›", p) {
            if (chapterIndex < chapters.size - 1) showReader(chapterIndex + 1, 0)
        }
        prev.alpha = if (index > 0) 1f else 0.3f
        next.alpha = if (index < chapters.size - 1) 1f else 0.3f
        val mid = barButton("☰ Chapitres", p) { showChapterList() }
        for (v in listOf(prev, mid, next)) {
            bottom.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        root.addView(bottom, LinearLayout.LayoutParams(MATCH, WRAP))

        setContentView(root)
        sv.postDelayed({ sv.scrollTo(0, y) }, 60)
    }

    // ---------- Dialogues ----------

    private fun showChapterList() {
        saveProgress()
        val titles = chapters.map { it.title }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Chapitres")
            .setItems(titles) { _, i -> showReader(i, 0) }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("À propos")
            .setMessage(
                "MON APPEL\n" +
                "DIZOLELE-MPUNGU WAFIDUSWA Isaac, Prophète de l’Éternel\n" +
                "Église Bon Nouveau Message (KCC) — Juillet 2010\n\n" +
                "© Texte : Dizolele-Mpungu Wafiduswa Isaac. Tous droits réservés.\n" +
                "Reproduction numérique réalisée avec autorisation.\n\n" +
                "Application créée par Zenilde Lutu\n" +
                "Version 1.0"
            )
            .setPositiveButton("OK", null)
            .show()
    }
}
